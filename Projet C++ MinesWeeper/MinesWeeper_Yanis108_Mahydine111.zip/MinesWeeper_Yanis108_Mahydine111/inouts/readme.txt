// Ces jeux de tests sont basés sur les exemples donnés dans le sujet.
// Ils n'ont pas la prétention d'être exhaustifs
// A vous de les compléter

in1.txt		-> entrée testant la commande 1

out1.txt	-> une sortie possible (les mines sont placées aléatoirement)

in2a.txt	
in2b.txt	
in2c.txt	-> entrées testant la commande 2

out2a.txt	
out2b.txt	
out2c.txt	-> sorties correspondantes

in3a.txt	
in3b.txt	
in3c.txt	-> entrées testant la commande 3

out3abc.txt	-> sortie correspondante

in4a.txt	
in4b.txt	
in4c.txt	-> entrées testant la commande 4

out4a.txt
out4bc.txt -> sorties correspondantes

in5.txt		-> entrée testant la commande 5

out5.txt	-> une sortie possible (le coup est choisi aléatoirement)

// Les coups possibles en sortie de in5.txt sont D1, D6, D7, D12, D13, D18, D19 et M1, M6, M7, M12, M13, M18, M19.